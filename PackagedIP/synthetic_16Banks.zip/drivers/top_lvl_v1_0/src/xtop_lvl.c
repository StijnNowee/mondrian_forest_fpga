// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xtop_lvl.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XTop_lvl_CfgInitialize(XTop_lvl *InstancePtr, XTop_lvl_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XTop_lvl_Start(XTop_lvl *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XTop_lvl_IsDone(XTop_lvl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XTop_lvl_IsIdle(XTop_lvl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XTop_lvl_IsReady(XTop_lvl *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XTop_lvl_Continue(XTop_lvl *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL) & 0x80;
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL, Data | 0x10);
}

void XTop_lvl_EnableAutoRestart(XTop_lvl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XTop_lvl_DisableAutoRestart(XTop_lvl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_AP_CTRL, 0);
}

void XTop_lvl_Set_sizes(XTop_lvl *InstancePtr, XTop_lvl_Sizes Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_SIZES_DATA + 0, Data.word_0);
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_SIZES_DATA + 4, Data.word_1);
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_SIZES_DATA + 8, Data.word_2);
}

XTop_lvl_Sizes XTop_lvl_Get_sizes(XTop_lvl *InstancePtr) {
    XTop_lvl_Sizes Data;

    Data.word_0 = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_SIZES_DATA + 0);
    Data.word_1 = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_SIZES_DATA + 4);
    Data.word_2 = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_SIZES_DATA + 8);
    return Data;
}

void XTop_lvl_Set_trainHBM_0(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_0_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_0_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_0(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_0_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_0_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_1(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_1_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_1_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_1(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_1_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_1_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_2(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_2_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_2_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_2(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_2_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_2_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_3(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_3_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_3_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_3(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_3_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_3_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_4(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_4_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_4_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_4(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_4_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_4_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_5(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_5_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_5_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_5(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_5_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_5_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_6(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_6_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_6_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_6(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_6_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_6_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_7(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_7_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_7_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_7(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_7_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_7_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_8(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_8_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_8_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_8(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_8_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_8_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_9(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_9_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_9_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_9(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_9_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_9_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_10(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_10_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_10_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_10(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_10_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_10_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_11(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_11_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_11_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_11(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_11_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_11_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_12(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_12_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_12_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_12(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_12_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_12_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_13(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_13_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_13_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_13(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_13_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_13_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_14(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_14_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_14_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_14(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_14_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_14_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_trainHBM_15(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_15_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_15_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_trainHBM_15(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_15_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_TRAINHBM_15_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_0(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_0_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_0_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_0(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_0_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_0_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_1(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_1_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_1_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_1(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_1_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_1_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_2(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_2_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_2_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_2(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_2_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_2_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_3(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_3_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_3_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_3(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_3_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_3_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_4(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_4_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_4_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_4(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_4_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_4_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_5(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_5_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_5_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_5(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_5_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_5_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_6(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_6_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_6_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_6(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_6_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_6_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_7(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_7_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_7_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_7(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_7_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_7_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_8(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_8_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_8_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_8(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_8_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_8_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_9(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_9_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_9_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_9(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_9_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_9_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_10(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_10_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_10_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_10(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_10_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_10_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_11(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_11_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_11_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_11(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_11_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_11_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_12(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_12_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_12_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_12(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_12_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_12_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_13(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_13_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_13_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_13(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_13_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_13_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_14(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_14_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_14_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_14(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_14_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_14_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_Set_inferenceHBM_15(XTop_lvl *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_15_DATA, (u32)(Data));
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_15_DATA + 4, (u32)(Data >> 32));
}

u64 XTop_lvl_Get_inferenceHBM_15(XTop_lvl *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_15_DATA);
    Data += (u64)XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_15_DATA + 4) << 32;
    return Data;
}

void XTop_lvl_InterruptGlobalEnable(XTop_lvl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_GIE, 1);
}

void XTop_lvl_InterruptGlobalDisable(XTop_lvl *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_GIE, 0);
}

void XTop_lvl_InterruptEnable(XTop_lvl *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_IER);
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_IER, Register | Mask);
}

void XTop_lvl_InterruptDisable(XTop_lvl *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_IER);
    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_IER, Register & (~Mask));
}

void XTop_lvl_InterruptClear(XTop_lvl *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XTop_lvl_WriteReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_ISR, Mask);
}

u32 XTop_lvl_InterruptGetEnabled(XTop_lvl *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_IER);
}

u32 XTop_lvl_InterruptGetStatus(XTop_lvl *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XTop_lvl_ReadReg(InstancePtr->Control_BaseAddress, XTOP_LVL_CONTROL_ADDR_ISR);
}

