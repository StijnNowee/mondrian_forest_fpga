// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XTOP_LVL_H
#define XTOP_LVL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xtop_lvl_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XTop_lvl_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XTop_lvl;

typedef u32 word_type;

typedef struct {
    u32 word_0;
    u32 word_1;
    u32 word_2;
} XTop_lvl_Sizes;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XTop_lvl_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XTop_lvl_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XTop_lvl_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XTop_lvl_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XTop_lvl_Initialize(XTop_lvl *InstancePtr, UINTPTR BaseAddress);
XTop_lvl_Config* XTop_lvl_LookupConfig(UINTPTR BaseAddress);
#else
int XTop_lvl_Initialize(XTop_lvl *InstancePtr, u16 DeviceId);
XTop_lvl_Config* XTop_lvl_LookupConfig(u16 DeviceId);
#endif
int XTop_lvl_CfgInitialize(XTop_lvl *InstancePtr, XTop_lvl_Config *ConfigPtr);
#else
int XTop_lvl_Initialize(XTop_lvl *InstancePtr, const char* InstanceName);
int XTop_lvl_Release(XTop_lvl *InstancePtr);
#endif

void XTop_lvl_Start(XTop_lvl *InstancePtr);
u32 XTop_lvl_IsDone(XTop_lvl *InstancePtr);
u32 XTop_lvl_IsIdle(XTop_lvl *InstancePtr);
u32 XTop_lvl_IsReady(XTop_lvl *InstancePtr);
void XTop_lvl_Continue(XTop_lvl *InstancePtr);
void XTop_lvl_EnableAutoRestart(XTop_lvl *InstancePtr);
void XTop_lvl_DisableAutoRestart(XTop_lvl *InstancePtr);

void XTop_lvl_Set_sizes(XTop_lvl *InstancePtr, XTop_lvl_Sizes Data);
XTop_lvl_Sizes XTop_lvl_Get_sizes(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_0(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_0(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_1(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_1(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_2(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_2(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_3(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_3(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_4(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_4(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_5(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_5(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_6(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_6(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_7(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_7(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_8(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_8(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_9(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_9(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_10(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_10(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_11(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_11(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_12(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_12(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_13(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_13(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_14(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_14(XTop_lvl *InstancePtr);
void XTop_lvl_Set_trainHBM_15(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_trainHBM_15(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_0(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_0(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_1(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_1(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_2(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_2(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_3(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_3(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_4(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_4(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_5(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_5(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_6(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_6(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_7(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_7(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_8(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_8(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_9(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_9(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_10(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_10(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_11(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_11(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_12(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_12(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_13(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_13(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_14(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_14(XTop_lvl *InstancePtr);
void XTop_lvl_Set_inferenceHBM_15(XTop_lvl *InstancePtr, u64 Data);
u64 XTop_lvl_Get_inferenceHBM_15(XTop_lvl *InstancePtr);

void XTop_lvl_InterruptGlobalEnable(XTop_lvl *InstancePtr);
void XTop_lvl_InterruptGlobalDisable(XTop_lvl *InstancePtr);
void XTop_lvl_InterruptEnable(XTop_lvl *InstancePtr, u32 Mask);
void XTop_lvl_InterruptDisable(XTop_lvl *InstancePtr, u32 Mask);
void XTop_lvl_InterruptClear(XTop_lvl *InstancePtr, u32 Mask);
u32 XTop_lvl_InterruptGetEnabled(XTop_lvl *InstancePtr);
u32 XTop_lvl_InterruptGetStatus(XTop_lvl *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
