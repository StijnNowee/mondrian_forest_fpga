// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x000 : Control signals
//         bit 0  - ap_start (Read/Write/COH)
//         bit 1  - ap_done (Read)
//         bit 2  - ap_idle (Read)
//         bit 3  - ap_ready (Read/COR)
//         bit 4  - ap_continue (Read/Write/SC)
//         bit 7  - auto_restart (Read/Write)
//         bit 9  - interrupt (Read)
//         others - reserved
// 0x004 : Global Interrupt Enable Register
//         bit 0  - Global Interrupt Enable (Read/Write)
//         others - reserved
// 0x008 : IP Interrupt Enable Register (Read/Write)
//         bit 0 - enable ap_done interrupt (Read/Write)
//         bit 1 - enable ap_ready interrupt (Read/Write)
//         others - reserved
// 0x00c : IP Interrupt Status Register (Read/TOW)
//         bit 0 - ap_done (Read/TOW)
//         bit 1 - ap_ready (Read/TOW)
//         others - reserved
// 0x010 : Data signal of sizes
//         bit 31~0 - sizes[31:0] (Read/Write)
// 0x014 : Data signal of sizes
//         bit 31~0 - sizes[63:32] (Read/Write)
// 0x018 : Data signal of sizes
//         bit 31~0 - sizes[95:64] (Read/Write)
// 0x01c : reserved
// 0x020 : Data signal of trainHBM_0
//         bit 31~0 - trainHBM_0[31:0] (Read/Write)
// 0x024 : Data signal of trainHBM_0
//         bit 31~0 - trainHBM_0[63:32] (Read/Write)
// 0x028 : reserved
// 0x02c : Data signal of trainHBM_1
//         bit 31~0 - trainHBM_1[31:0] (Read/Write)
// 0x030 : Data signal of trainHBM_1
//         bit 31~0 - trainHBM_1[63:32] (Read/Write)
// 0x034 : reserved
// 0x038 : Data signal of trainHBM_2
//         bit 31~0 - trainHBM_2[31:0] (Read/Write)
// 0x03c : Data signal of trainHBM_2
//         bit 31~0 - trainHBM_2[63:32] (Read/Write)
// 0x040 : reserved
// 0x044 : Data signal of trainHBM_3
//         bit 31~0 - trainHBM_3[31:0] (Read/Write)
// 0x048 : Data signal of trainHBM_3
//         bit 31~0 - trainHBM_3[63:32] (Read/Write)
// 0x04c : reserved
// 0x050 : Data signal of trainHBM_4
//         bit 31~0 - trainHBM_4[31:0] (Read/Write)
// 0x054 : Data signal of trainHBM_4
//         bit 31~0 - trainHBM_4[63:32] (Read/Write)
// 0x058 : reserved
// 0x05c : Data signal of trainHBM_5
//         bit 31~0 - trainHBM_5[31:0] (Read/Write)
// 0x060 : Data signal of trainHBM_5
//         bit 31~0 - trainHBM_5[63:32] (Read/Write)
// 0x064 : reserved
// 0x068 : Data signal of trainHBM_6
//         bit 31~0 - trainHBM_6[31:0] (Read/Write)
// 0x06c : Data signal of trainHBM_6
//         bit 31~0 - trainHBM_6[63:32] (Read/Write)
// 0x070 : reserved
// 0x074 : Data signal of trainHBM_7
//         bit 31~0 - trainHBM_7[31:0] (Read/Write)
// 0x078 : Data signal of trainHBM_7
//         bit 31~0 - trainHBM_7[63:32] (Read/Write)
// 0x07c : reserved
// 0x080 : Data signal of trainHBM_8
//         bit 31~0 - trainHBM_8[31:0] (Read/Write)
// 0x084 : Data signal of trainHBM_8
//         bit 31~0 - trainHBM_8[63:32] (Read/Write)
// 0x088 : reserved
// 0x08c : Data signal of trainHBM_9
//         bit 31~0 - trainHBM_9[31:0] (Read/Write)
// 0x090 : Data signal of trainHBM_9
//         bit 31~0 - trainHBM_9[63:32] (Read/Write)
// 0x094 : reserved
// 0x098 : Data signal of trainHBM_10
//         bit 31~0 - trainHBM_10[31:0] (Read/Write)
// 0x09c : Data signal of trainHBM_10
//         bit 31~0 - trainHBM_10[63:32] (Read/Write)
// 0x0a0 : reserved
// 0x0a4 : Data signal of trainHBM_11
//         bit 31~0 - trainHBM_11[31:0] (Read/Write)
// 0x0a8 : Data signal of trainHBM_11
//         bit 31~0 - trainHBM_11[63:32] (Read/Write)
// 0x0ac : reserved
// 0x0b0 : Data signal of trainHBM_12
//         bit 31~0 - trainHBM_12[31:0] (Read/Write)
// 0x0b4 : Data signal of trainHBM_12
//         bit 31~0 - trainHBM_12[63:32] (Read/Write)
// 0x0b8 : reserved
// 0x0bc : Data signal of trainHBM_13
//         bit 31~0 - trainHBM_13[31:0] (Read/Write)
// 0x0c0 : Data signal of trainHBM_13
//         bit 31~0 - trainHBM_13[63:32] (Read/Write)
// 0x0c4 : reserved
// 0x0c8 : Data signal of trainHBM_14
//         bit 31~0 - trainHBM_14[31:0] (Read/Write)
// 0x0cc : Data signal of trainHBM_14
//         bit 31~0 - trainHBM_14[63:32] (Read/Write)
// 0x0d0 : reserved
// 0x0d4 : Data signal of trainHBM_15
//         bit 31~0 - trainHBM_15[31:0] (Read/Write)
// 0x0d8 : Data signal of trainHBM_15
//         bit 31~0 - trainHBM_15[63:32] (Read/Write)
// 0x0dc : reserved
// 0x0e0 : Data signal of inferenceHBM_0
//         bit 31~0 - inferenceHBM_0[31:0] (Read/Write)
// 0x0e4 : Data signal of inferenceHBM_0
//         bit 31~0 - inferenceHBM_0[63:32] (Read/Write)
// 0x0e8 : reserved
// 0x0ec : Data signal of inferenceHBM_1
//         bit 31~0 - inferenceHBM_1[31:0] (Read/Write)
// 0x0f0 : Data signal of inferenceHBM_1
//         bit 31~0 - inferenceHBM_1[63:32] (Read/Write)
// 0x0f4 : reserved
// 0x0f8 : Data signal of inferenceHBM_2
//         bit 31~0 - inferenceHBM_2[31:0] (Read/Write)
// 0x0fc : Data signal of inferenceHBM_2
//         bit 31~0 - inferenceHBM_2[63:32] (Read/Write)
// 0x100 : reserved
// 0x104 : Data signal of inferenceHBM_3
//         bit 31~0 - inferenceHBM_3[31:0] (Read/Write)
// 0x108 : Data signal of inferenceHBM_3
//         bit 31~0 - inferenceHBM_3[63:32] (Read/Write)
// 0x10c : reserved
// 0x110 : Data signal of inferenceHBM_4
//         bit 31~0 - inferenceHBM_4[31:0] (Read/Write)
// 0x114 : Data signal of inferenceHBM_4
//         bit 31~0 - inferenceHBM_4[63:32] (Read/Write)
// 0x118 : reserved
// 0x11c : Data signal of inferenceHBM_5
//         bit 31~0 - inferenceHBM_5[31:0] (Read/Write)
// 0x120 : Data signal of inferenceHBM_5
//         bit 31~0 - inferenceHBM_5[63:32] (Read/Write)
// 0x124 : reserved
// 0x128 : Data signal of inferenceHBM_6
//         bit 31~0 - inferenceHBM_6[31:0] (Read/Write)
// 0x12c : Data signal of inferenceHBM_6
//         bit 31~0 - inferenceHBM_6[63:32] (Read/Write)
// 0x130 : reserved
// 0x134 : Data signal of inferenceHBM_7
//         bit 31~0 - inferenceHBM_7[31:0] (Read/Write)
// 0x138 : Data signal of inferenceHBM_7
//         bit 31~0 - inferenceHBM_7[63:32] (Read/Write)
// 0x13c : reserved
// 0x140 : Data signal of inferenceHBM_8
//         bit 31~0 - inferenceHBM_8[31:0] (Read/Write)
// 0x144 : Data signal of inferenceHBM_8
//         bit 31~0 - inferenceHBM_8[63:32] (Read/Write)
// 0x148 : reserved
// 0x14c : Data signal of inferenceHBM_9
//         bit 31~0 - inferenceHBM_9[31:0] (Read/Write)
// 0x150 : Data signal of inferenceHBM_9
//         bit 31~0 - inferenceHBM_9[63:32] (Read/Write)
// 0x154 : reserved
// 0x158 : Data signal of inferenceHBM_10
//         bit 31~0 - inferenceHBM_10[31:0] (Read/Write)
// 0x15c : Data signal of inferenceHBM_10
//         bit 31~0 - inferenceHBM_10[63:32] (Read/Write)
// 0x160 : reserved
// 0x164 : Data signal of inferenceHBM_11
//         bit 31~0 - inferenceHBM_11[31:0] (Read/Write)
// 0x168 : Data signal of inferenceHBM_11
//         bit 31~0 - inferenceHBM_11[63:32] (Read/Write)
// 0x16c : reserved
// 0x170 : Data signal of inferenceHBM_12
//         bit 31~0 - inferenceHBM_12[31:0] (Read/Write)
// 0x174 : Data signal of inferenceHBM_12
//         bit 31~0 - inferenceHBM_12[63:32] (Read/Write)
// 0x178 : reserved
// 0x17c : Data signal of inferenceHBM_13
//         bit 31~0 - inferenceHBM_13[31:0] (Read/Write)
// 0x180 : Data signal of inferenceHBM_13
//         bit 31~0 - inferenceHBM_13[63:32] (Read/Write)
// 0x184 : reserved
// 0x188 : Data signal of inferenceHBM_14
//         bit 31~0 - inferenceHBM_14[31:0] (Read/Write)
// 0x18c : Data signal of inferenceHBM_14
//         bit 31~0 - inferenceHBM_14[63:32] (Read/Write)
// 0x190 : reserved
// 0x194 : Data signal of inferenceHBM_15
//         bit 31~0 - inferenceHBM_15[31:0] (Read/Write)
// 0x198 : Data signal of inferenceHBM_15
//         bit 31~0 - inferenceHBM_15[63:32] (Read/Write)
// 0x19c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XTOP_LVL_CONTROL_ADDR_AP_CTRL              0x000
#define XTOP_LVL_CONTROL_ADDR_GIE                  0x004
#define XTOP_LVL_CONTROL_ADDR_IER                  0x008
#define XTOP_LVL_CONTROL_ADDR_ISR                  0x00c
#define XTOP_LVL_CONTROL_ADDR_SIZES_DATA           0x010
#define XTOP_LVL_CONTROL_BITS_SIZES_DATA           96
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_0_DATA      0x020
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_0_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_1_DATA      0x02c
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_1_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_2_DATA      0x038
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_2_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_3_DATA      0x044
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_3_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_4_DATA      0x050
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_4_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_5_DATA      0x05c
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_5_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_6_DATA      0x068
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_6_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_7_DATA      0x074
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_7_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_8_DATA      0x080
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_8_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_9_DATA      0x08c
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_9_DATA      64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_10_DATA     0x098
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_10_DATA     64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_11_DATA     0x0a4
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_11_DATA     64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_12_DATA     0x0b0
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_12_DATA     64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_13_DATA     0x0bc
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_13_DATA     64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_14_DATA     0x0c8
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_14_DATA     64
#define XTOP_LVL_CONTROL_ADDR_TRAINHBM_15_DATA     0x0d4
#define XTOP_LVL_CONTROL_BITS_TRAINHBM_15_DATA     64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_0_DATA  0x0e0
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_0_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_1_DATA  0x0ec
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_1_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_2_DATA  0x0f8
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_2_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_3_DATA  0x104
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_3_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_4_DATA  0x110
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_4_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_5_DATA  0x11c
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_5_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_6_DATA  0x128
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_6_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_7_DATA  0x134
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_7_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_8_DATA  0x140
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_8_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_9_DATA  0x14c
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_9_DATA  64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_10_DATA 0x158
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_10_DATA 64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_11_DATA 0x164
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_11_DATA 64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_12_DATA 0x170
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_12_DATA 64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_13_DATA 0x17c
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_13_DATA 64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_14_DATA 0x188
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_14_DATA 64
#define XTOP_LVL_CONTROL_ADDR_INFERENCEHBM_15_DATA 0x194
#define XTOP_LVL_CONTROL_BITS_INFERENCEHBM_15_DATA 64

